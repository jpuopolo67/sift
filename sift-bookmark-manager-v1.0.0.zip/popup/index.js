import{u as e,d as h,y as $,A as F,k as Z,G as Q}from"../chunks/hooks.module-B8iQioIS.js";function W(r){return r>=70?"good":r>=40?"medium":"poor"}function Y(r){return r>=80?"Excellent":r>=70?"Good":r>=50?"Fair":r>=30?"Needs Work":"Poor"}function J(r,l){const i=[];return l>0&&i.push(`${l} duplicate${l>1?"s":""}`),r.deadLinks.length>0&&i.push(`${r.deadLinks.length} dead link${r.deadLinks.length>1?"s":""}`),r.staleBookmarks.length>0&&i.push(`${r.staleBookmarks.length} stale`),r.uncategorizedCount>10&&i.push(`${r.uncategorizedCount} uncategorized`),i.length===0?"Your bookmarks are well organized!":`Score affected by: ${i.join(", ")}`}function X({metrics:r}){const l=r.duplicates.reduce((i,o)=>i+o.bookmarks.length-1,0);return e("div",{children:[e("div",{class:"health-score",children:[e("div",{class:`score-circle ${W(r.healthScore)}`,children:r.healthScore}),e("span",{class:"score-label",children:Y(r.healthScore)}),e("p",{class:"score-explanation",children:J(r,l)})]}),e("div",{class:"metrics-grid",children:[e("div",{class:"metric-card",children:[e("div",{class:"metric-value",children:r.totalBookmarks}),e("div",{class:"metric-label",children:"Total Bookmarks"})]}),e("div",{class:"metric-card",children:[e("div",{class:"metric-value",children:r.totalFolders}),e("div",{class:"metric-label",children:"Folders"})]}),e("div",{class:`metric-card ${l>0?"warning":""}`,children:[e("div",{class:"metric-value",children:l}),e("div",{class:"metric-label",children:"Duplicates"})]}),e("div",{class:`metric-card ${r.deadLinks.length>0?"danger":""}`,children:[e("div",{class:"metric-value",children:r.deadLinks.length}),e("div",{class:"metric-label",children:"Dead Links"})]}),e("div",{class:`metric-card ${r.staleBookmarks.length>0?"warning":""}`,children:[e("div",{class:"metric-value",children:r.staleBookmarks.length}),e("div",{class:"metric-label",children:"Stale (180+ days)"})]}),e("div",{class:`metric-card ${r.uncategorizedCount>10?"warning":""}`,children:[e("div",{class:"metric-value",children:r.uncategorizedCount}),e("div",{class:"metric-label",children:"Uncategorized"})]})]})]})}function q(r){try{return`https://www.google.com/s2/favicons?domain=${new URL(r).hostname}&sz=32`}catch{return""}}function ee({query:r,results:l,onSearch:i}){return e("div",{children:[e("div",{class:"search-container",children:e("input",{type:"text",class:"search-input",placeholder:"Search bookmarks...",value:r,onInput:o=>i(o.target.value)})}),r&&l.length===0&&e("div",{class:"empty-state",children:e("p",{children:['No bookmarks found for "',r,'"']})}),l.length>0&&e("div",{class:"bookmark-list",children:l.map(o=>e("div",{class:"bookmark-item",children:[e("img",{class:"bookmark-favicon",src:q(o.url),alt:""}),e("div",{class:"bookmark-info",children:e("a",{href:o.url,target:"_blank",rel:"noopener noreferrer",children:[e("div",{class:"bookmark-title",children:o.title||"Untitled"}),e("div",{class:"bookmark-url",children:o.url})]})})]},o.id))}),!r&&e("div",{class:"empty-state",children:e("p",{children:"Enter a keyword to search your bookmarks"})})]})}function re({groups:r,onClose:l,onRemove:i,onStatusChange:o}){const[w,m]=h({}),[k,v]=h(!0);$(()=>{g()},[r]);async function g(){v(!0);const p=r.flatMap(t=>t.bookmarks.map(b=>b.id));o(`Loading paths for ${p.length} bookmarks...`);try{const t=await chrome.runtime.sendMessage({type:"GET_BOOKMARK_PATHS",bookmarkIds:p});t&&!t.error&&(m(t),o(`Showing ${r.length} duplicate groups`))}catch(t){console.error("Failed to load paths:",t),o("Failed to load bookmark paths")}v(!1)}const y=r.reduce((p,t)=>p+t.bookmarks.length-1,0);return k?e("div",{class:"duplicates-panel",children:[e("div",{class:"duplicates-header",children:[e("h3",{children:"Duplicate Bookmarks"}),e("button",{class:"close-btn",onClick:l,children:"×"})]}),e("div",{class:"loading",children:[e("div",{class:"spinner"}),e("span",{children:"Loading duplicates..."})]})]}):e("div",{class:"duplicates-panel",children:[e("div",{class:"duplicates-header",children:[e("h3",{children:["Duplicate Bookmarks (",y,")"]}),e("button",{class:"close-btn",onClick:l,children:"×"})]}),e("div",{class:"duplicates-content",children:r.map((p,t)=>e("div",{class:"duplicate-group",children:[e("div",{class:"group-header",children:[e("span",{class:"group-count",children:[p.bookmarks.length," copies"]}),e("span",{class:"group-url",title:p.normalizedUrl,children:ne(p.normalizedUrl)})]}),e("div",{class:"group-bookmarks",children:p.bookmarks.map(b=>e("div",{class:"duplicate-item",children:[e("div",{class:"duplicate-title",children:b.title||"Untitled"}),e("div",{class:"duplicate-path",children:w[b.id]||"Loading..."}),e("div",{class:"duplicate-url",children:e("a",{href:b.url,target:"_blank",rel:"noopener noreferrer",children:b.url})})]},b.id))})]},t))}),e("div",{class:"duplicates-footer",children:[e("button",{class:"btn btn-secondary",onClick:l,children:"Cancel"}),e("button",{class:"btn btn-danger",onClick:i,children:["Remove ",y," Duplicates"]})]}),e("style",{children:`
        .duplicates-panel {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: #f5f5f5;
          z-index: 100;
          display: flex;
          flex-direction: column;
        }

        .duplicates-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px;
          background: white;
          border-bottom: 1px solid #dee2e6;
        }

        .duplicates-header h3 {
          margin: 0;
          font-size: 16px;
          font-weight: 600;
        }

        .close-btn {
          background: none;
          border: none;
          font-size: 24px;
          cursor: pointer;
          color: #6c757d;
          padding: 0;
          line-height: 1;
        }

        .close-btn:hover {
          color: #343a40;
        }

        .duplicates-content {
          flex: 1;
          overflow-y: auto;
          padding: 16px;
        }

        .duplicate-group {
          background: white;
          border-radius: 8px;
          margin-bottom: 12px;
          overflow: hidden;
        }

        .group-header {
          padding: 12px;
          background: #e9ecef;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 8px;
        }

        .group-count {
          font-weight: 600;
          color: #dc3545;
          white-space: nowrap;
        }

        .group-url {
          font-size: 12px;
          color: #6c757d;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .group-bookmarks {
          padding: 8px;
        }

        .duplicate-item {
          padding: 10px;
          border-bottom: 1px solid #e9ecef;
        }

        .duplicate-item:last-child {
          border-bottom: none;
        }

        .duplicate-title {
          font-weight: 500;
          color: #343a40;
          margin-bottom: 4px;
        }

        .duplicate-path {
          font-size: 12px;
          color: #6c757d;
          margin-bottom: 4px;
        }

        .duplicate-url {
          font-size: 12px;
        }

        .duplicate-url a {
          color: #4a90d9;
          text-decoration: none;
          word-break: break-all;
        }

        .duplicate-url a:hover {
          text-decoration: underline;
        }

        .duplicates-footer {
          padding: 16px;
          background: white;
          border-top: 1px solid #dee2e6;
          display: flex;
          gap: 12px;
          justify-content: flex-end;
        }

        .btn-danger {
          background: #dc3545;
        }

        .btn-danger:hover {
          background: #c82333;
        }
      `})]})}function ne(r,l=40){return r.length<=l?r:r.substring(0,l)+"..."}function te({bookmarks:r,onClose:l,onDelete:i,onStatusChange:o}){const[w,m]=h({}),[k,v]=h(!0),[g,y]=h(new Set(r.map(a=>a.id)));$(()=>{p()},[r]);async function p(){v(!0);const a=r.map(c=>c.id);o(`Loading paths for ${a.length} dead links...`);try{const c=await chrome.runtime.sendMessage({type:"GET_BOOKMARK_PATHS",bookmarkIds:a});c&&!c.error&&(m(c),o(`Found ${r.length} dead links`))}catch(c){console.error("Failed to load paths:",c),o("Failed to load bookmark paths")}v(!1)}function t(a){const c=new Set(g);c.has(a)?c.delete(a):c.add(a),y(c)}function b(){y(new Set(r.map(a=>a.id)))}function s(){y(new Set)}function C(){const a=r.filter(c=>g.has(c.id));i(a)}return k?e("div",{class:"dead-links-panel",children:[e("div",{class:"dead-links-header",children:[e("h3",{children:"Dead Links"}),e("button",{class:"close-btn",onClick:l,children:"×"})]}),e("div",{class:"loading",children:[e("div",{class:"spinner"}),e("span",{children:"Loading dead links..."})]})]}):e("div",{class:"dead-links-panel",children:[e("div",{class:"dead-links-header",children:[e("h3",{children:["Dead Links (",r.length,")"]}),e("button",{class:"close-btn",onClick:l,children:"×"})]}),e("div",{class:"dead-links-toolbar",children:[e("span",{children:[g.size," selected"]}),e("div",{class:"toolbar-actions",children:[e("button",{class:"link-btn",onClick:b,children:"Select All"}),e("button",{class:"link-btn",onClick:s,children:"Select None"})]})]}),e("div",{class:"dead-links-content",children:r.map(a=>e("div",{class:`dead-link-item ${g.has(a.id)?"selected":""}`,onClick:()=>t(a.id),children:[e("input",{type:"checkbox",checked:g.has(a.id),onChange:()=>t(a.id)}),e("div",{class:"dead-link-info",children:[e("div",{class:"dead-link-title",children:a.title||"Untitled"}),e("div",{class:"dead-link-path",children:w[a.id]||"Loading..."}),e("div",{class:"dead-link-url",children:e("a",{href:a.url,target:"_blank",rel:"noopener noreferrer",onClick:c=>c.stopPropagation(),children:a.url})})]})]},a.id))}),e("div",{class:"dead-links-footer",children:[e("button",{class:"btn btn-primary",onClick:l,children:"Keep All"}),e("button",{class:"btn btn-danger",onClick:C,disabled:g.size===0,children:["Delete ",g.size," Dead Links"]})]}),e("style",{children:`
        .dead-links-panel {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: #f5f5f5;
          z-index: 100;
          display: flex;
          flex-direction: column;
        }

        .dead-links-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px;
          background: white;
          border-bottom: 1px solid #dee2e6;
        }

        .dead-links-header h3 {
          margin: 0;
          font-size: 16px;
          font-weight: 600;
        }

        .close-btn {
          background: none;
          border: none;
          font-size: 24px;
          cursor: pointer;
          color: #6c757d;
          padding: 0;
          line-height: 1;
        }

        .close-btn:hover {
          color: #343a40;
        }

        .dead-links-toolbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 16px;
          background: white;
          border-bottom: 1px solid #dee2e6;
          font-size: 13px;
        }

        .toolbar-actions {
          display: flex;
          gap: 12px;
        }

        .link-btn {
          background: none;
          border: none;
          color: #4a90d9;
          cursor: pointer;
          font-size: 13px;
          padding: 0;
        }

        .link-btn:hover {
          text-decoration: underline;
        }

        .dead-links-content {
          flex: 1;
          overflow-y: auto;
          padding: 16px;
        }

        .dead-link-item {
          background: white;
          border-radius: 8px;
          padding: 12px;
          margin-bottom: 8px;
          display: flex;
          gap: 12px;
          cursor: pointer;
          border: 2px solid transparent;
          transition: border-color 0.2s;
        }

        .dead-link-item:hover {
          border-color: #dee2e6;
        }

        .dead-link-item.selected {
          border-color: #4a90d9;
          background: #f0f7ff;
        }

        .dead-link-item input[type="checkbox"] {
          margin-top: 2px;
          cursor: pointer;
        }

        .dead-link-info {
          flex: 1;
          min-width: 0;
        }

        .dead-link-title {
          font-weight: 500;
          color: #343a40;
          margin-bottom: 4px;
        }

        .dead-link-path {
          font-size: 12px;
          color: #6c757d;
          margin-bottom: 4px;
        }

        .dead-link-url {
          font-size: 12px;
        }

        .dead-link-url a {
          color: #dc3545;
          text-decoration: none;
          word-break: break-all;
        }

        .dead-link-url a:hover {
          text-decoration: underline;
        }

        .dead-links-footer {
          padding: 16px;
          background: white;
          border-top: 1px solid #dee2e6;
          display: flex;
          gap: 12px;
          justify-content: flex-end;
        }

        .btn-danger {
          background: #dc3545;
          color: white;
        }

        .btn-danger:hover {
          background: #c82333;
        }

        .btn-danger:disabled {
          background: #e9ecef;
          color: #6c757d;
        }
      `})]})}function ie({metrics:r,onActionComplete:l,onStatusChange:i}){const[o,w]=h(null),[m,k]=h(null),[v,g]=h(!1),[y,p]=h(!1),[t,b]=h(null),[s,C]=h(null),a=F(null),c=F(null);$(()=>(x(),E(),()=>{a.current&&clearInterval(a.current),c.current&&clearInterval(c.current)}),[]),$(()=>{(t==null?void 0:t.status)==="running"?(a.current||(a.current=window.setInterval(x,1e3)),i(`Checking links: ${t.checked}/${t.total} (${t.deadLinks.length} dead found)`)):(a.current&&(clearInterval(a.current),a.current=null),(t==null?void 0:t.status)==="completed"&&t.deadLinks.length>0&&i(`Found ${t.deadLinks.length} dead links - click "View Results" to see them`))},[t]),$(()=>{if((s==null?void 0:s.status)==="running"){c.current||(c.current=window.setInterval(E,500));const n=D(s);i(n)}else c.current&&(clearInterval(c.current),c.current=null),(s==null?void 0:s.status)==="completed"&&!s.error&&i(`Categorization complete! Created ${s.categoriesCreated} folders with ${s.bookmarksCopied} bookmarks in Sift/${s.siftFolderName}`)},[s]);function D(n){switch(n.phase){case"fetching":return"Fetching bookmarks...";case"analyzing":return`Analyzing with AI: batch ${n.currentBatch}/${n.totalBatches}`;case"creating":return`Creating folders: ${n.bookmarksCopied} bookmarks copied`;case"done":return"Categorization complete!";default:return"Processing..."}}async function x(){try{const n=await chrome.runtime.sendMessage({type:"GET_DEAD_LINK_CHECK_STATUS"});b(n)}catch(n){console.error("Failed to get dead link check status:",n)}}async function E(){try{const n=await chrome.runtime.sendMessage({type:"GET_CATEGORIZATION_STATUS"});C(n)}catch(n){console.error("Failed to get categorization status:",n)}}const d=r.duplicates.reduce((n,u)=>n+u.bookmarks.length-1,0);async function f(n,u){w(n),k(null),i(`${n}...`);try{await u(),k(`${n} completed successfully`),i(`${n} completed`),l()}catch(S){const B=S instanceof Error?S.message:"Unknown error";k(`Error: ${B}`),i(`Error: ${B}`)}w(null)}async function L(){g(!1),await f("Remove duplicates",async()=>{i(`Removing ${d} duplicate bookmarks...`);const n=await chrome.runtime.sendMessage({type:"REMOVE_DUPLICATES",groups:r.duplicates});if(n.error)throw new Error(n.error);i(`Removed ${n.removed} duplicate bookmarks`)})}async function A(){await f("Delete stale bookmarks",async()=>{i(`Deleting ${r.staleBookmarks.length} stale bookmarks...`);const n=await chrome.runtime.sendMessage({type:"DELETE_STALE",bookmarks:r.staleBookmarks});if(n.error)throw new Error(n.error);i(`Deleted ${n.deleted} stale bookmarks`)})}async function M(){await f("Sort bookmarks",async()=>{i("Sorting all folders alphabetically...");const n=await chrome.runtime.sendMessage({type:"SORT_BOOKMARKS"});if(n.error)throw new Error(n.error);i("All folders sorted alphabetically")})}async function O(){try{i("Starting dead link check...");const n=await chrome.runtime.sendMessage({type:"START_DEAD_LINK_CHECK"});n.started?(n.skipped&&n.skipped>0&&i(`Starting check... (${n.skipped} links skipped - recently checked)`),await x()):(k(n.message||"Failed to start check"),i(n.message||"Failed to start check"))}catch(n){const u=n instanceof Error?n.message:"Unknown error";k(`Error: ${u}`),i(`Error: ${u}`)}}async function P(){try{await chrome.runtime.sendMessage({type:"CANCEL_DEAD_LINK_CHECK"}),await x(),i("Dead link check cancelled")}catch(n){console.error("Failed to cancel check:",n)}}async function K(){try{await chrome.runtime.sendMessage({type:"CLEAR_DEAD_LINK_RESULTS"}),await x(),i("Ready")}catch(n){console.error("Failed to clear results:",n)}}async function U(){try{if(!(await chrome.runtime.sendMessage({type:"GET_SETTINGS"})).claudeApiKey){k("Claude API key required. Opening settings..."),i("Claude API key required - configure in Settings"),chrome.runtime.openOptionsPage();return}i("Starting AI categorization...");const u=await chrome.runtime.sendMessage({type:"START_CATEGORIZATION"});u.started?await E():(k(u.message||"Failed to start categorization"),i(u.message||"Failed to start categorization"))}catch(n){const u=n instanceof Error?n.message:"Unknown error";k(`Error: ${u}`),i(`Error: ${u}`)}}async function N(){try{await chrome.runtime.sendMessage({type:"CANCEL_CATEGORIZATION"}),await E(),i("Categorization cancelled")}catch(n){console.error("Failed to cancel categorization:",n)}}async function _(){try{await chrome.runtime.sendMessage({type:"CLEAR_CATEGORIZATION_RESULTS"}),await E(),i("Ready"),l()}catch(n){console.error("Failed to clear categorization results:",n)}}async function G(n){p(!1),await f("Delete dead links",async()=>{i(`Deleting ${n.length} dead links...`);const u=await chrome.runtime.sendMessage({type:"DELETE_DEAD_LINKS",bookmarks:n});if(u.error)throw new Error(u.error);await chrome.runtime.sendMessage({type:"CLEAR_DEAD_LINK_RESULTS"}),await x(),i(`Deleted ${u.deleted} dead links`)})}if(y&&(t!=null&&t.deadLinks)&&t.deadLinks.length>0)return e(te,{bookmarks:t.deadLinks,onClose:()=>p(!1),onDelete:G,onStatusChange:i});if(v)return e(re,{groups:r.duplicates,onClose:()=>g(!1),onRemove:L,onStatusChange:i});const R=(t==null?void 0:t.status)==="running",H=(t==null?void 0:t.status)==="completed"&&t.deadLinks.length>0,z=t&&t.total>0?Math.round(t.checked/t.total*100):0,T=(s==null?void 0:s.status)==="running",j=(s==null?void 0:s.status)==="completed"&&!s.error,V=(s==null?void 0:s.status)==="completed"&&s.error,I=s&&s.totalBatches>0?Math.round(s.currentBatch/s.totalBatches*100):0;return e("div",{children:[m&&e("div",{class:`metric-card ${m.startsWith("Error")?"danger":""}`,style:{marginBottom:"16px"},children:e("div",{class:"metric-label",children:m})}),R&&e("div",{class:"progress-container",children:[e("div",{class:"progress-header",children:[e("span",{children:"Checking links (runs in background)..."}),e("span",{children:[t.checked," / ",t.total]})]}),e("div",{class:"progress-bar",children:e("div",{class:"progress-fill",style:{width:`${z}%`}})}),e("div",{class:"progress-details",children:[e("span",{children:[z,"% complete"]}),e("span",{children:[t.deadLinks.length," dead links found"]})]}),e("button",{class:"btn btn-secondary",onClick:P,style:{marginTop:"8px",width:"100%"},children:"Cancel Check"})]}),H&&e("div",{class:"progress-container",children:[e("div",{class:"progress-header",children:e("span",{children:"Dead Link Check Complete"})}),e("div",{class:"progress-details",style:{marginTop:"0"},children:e("span",{children:["Found ",t.deadLinks.length," dead link",t.deadLinks.length===1?"":"s"]})}),e("div",{class:"action-row",style:{marginTop:"12px"},children:[e("button",{class:"btn btn-primary",onClick:()=>p(!0),children:"View Results"}),e("button",{class:"btn btn-secondary",onClick:K,children:"Dismiss"})]})]}),e("div",{class:"section-header",children:e("span",{class:"section-title",children:"Cleanup Actions"})}),e("div",{class:"actions",children:[e("button",{class:"btn btn-primary",onClick:M,disabled:o!==null,children:o==="Sort bookmarks"?"Sorting...":"Sort Folders & Bookmarks"}),e("div",{class:"action-row",children:[e("button",{class:"btn btn-primary",onClick:()=>g(!0),disabled:o!==null||d===0,children:["View Duplicates (",d,")"]}),e("button",{class:"btn btn-primary",onClick:L,disabled:o!==null||d===0,children:o==="Remove duplicates"?"Removing...":"Remove Duplicates"})]}),e("button",{class:"btn btn-primary",onClick:A,disabled:o!==null||r.staleBookmarks.length===0,children:o==="Delete stale bookmarks"?"Deleting...":`Delete Stale Bookmarks (${r.staleBookmarks.length})`}),e("button",{class:"btn btn-primary",onClick:O,disabled:o!==null||R,children:R?`Checking... (${z}%)`:"Check Dead Links"})]}),e("div",{class:"section-header",style:{marginTop:"16px"},children:e("span",{class:"section-title",children:"AI Features"})}),T&&s&&e("div",{class:"progress-container",children:[e("div",{class:"progress-header",children:[e("span",{children:"AI Categorization (runs in background)..."}),e("span",{children:s.phase==="analyzing"?`${s.currentBatch}/${s.totalBatches} batches`:s.phase==="creating"?`${s.bookmarksCopied} bookmarks`:""})]}),e("div",{class:"progress-bar",children:e("div",{class:"progress-fill",style:{width:`${I}%`}})}),e("div",{class:"progress-details",children:[e("span",{children:D(s)}),e("span",{children:[I,"% complete"]})]}),e("button",{class:"btn btn-secondary",onClick:N,style:{marginTop:"8px",width:"100%"},children:"Cancel"})]}),j&&s&&e("div",{class:"progress-container",children:[e("div",{class:"progress-header",children:e("span",{children:"Categorization Complete"})}),e("div",{class:"progress-details",style:{marginTop:"0"},children:e("span",{children:["Created ",s.categoriesCreated," folders with ",s.bookmarksCopied," bookmarks"]})}),e("div",{class:"progress-details",style:{marginTop:"4px"},children:e("span",{children:["Location: Sift/",s.siftFolderName]})}),e("button",{class:"btn btn-secondary",onClick:_,style:{marginTop:"12px",width:"100%"},children:"Dismiss"})]}),V&&s&&e("div",{class:"progress-container",style:{borderLeft:"3px solid #dc3545"},children:[e("div",{class:"progress-header",children:e("span",{children:"Categorization Failed"})}),e("div",{class:"progress-details",style:{marginTop:"0",color:"#dc3545"},children:e("span",{children:s.error})}),e("button",{class:"btn btn-secondary",onClick:_,style:{marginTop:"12px",width:"100%"},children:"Dismiss"})]}),e("div",{class:"actions",children:[e("button",{class:"btn btn-primary",onClick:U,disabled:o!==null||T,children:T?`Categorizing... (${I}%)`:"Restructure Folders & Bookmarks"}),e("p",{class:"ai-hint",children:"Uses Claude Haiku 4.5. Requires a Claude API key, configured in settings and kept private. Creates a new Sift subfolder so that your original bookmarks are preserved."})]}),e("style",{children:`
        .action-row {
          display: flex;
          gap: 8px;
        }

        .action-row .btn {
          flex: 1;
        }

        .ai-hint {
          font-size: 11px;
          color: #6c757d;
          margin: 8px 0 0 0;
          line-height: 1.4;
        }

        .progress-container {
          background: white;
          border-radius: 8px;
          padding: 12px;
          margin-bottom: 12px;
        }

        .progress-header {
          display: flex;
          justify-content: space-between;
          margin-bottom: 4px;
          font-size: 14px;
          font-weight: 500;
        }

        .progress-bar {
          height: 12px;
          background: #e9ecef;
          border-radius: 6px;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          background: #4a90d9;
          border-radius: 6px;
          transition: width 0.3s ease;
        }

        .progress-details {
          display: flex;
          justify-content: space-between;
          margin-top: 4px;
          font-size: 12px;
          color: #6c757d;
        }
      `})]})}function se(){const[r,l]=h("dashboard"),[i,o]=h(null),[w,m]=h(!0),[k,v]=h([]),[g,y]=h(""),[p,t]=h("Ready"),[b,s]=h("Ready"),[C,a]=h("Enter a search term");$(()=>{c()},[]);async function c(){m(!0),t("Loading bookmarks...");try{t("Analyzing bookmark health...");const d=await chrome.runtime.sendMessage({type:"GET_HEALTH_METRICS"});if(d&&!d.error){o(d);const f=d.duplicates.reduce((L,A)=>L+A.bookmarks.length-1,0);t(`Found ${d.totalBookmarks} bookmarks, ${f} duplicates, ${d.staleBookmarks.length} stale`),s("Select an action to clean up your bookmarks")}else d!=null&&d.error&&t(`Error: ${d.error}`)}catch(d){console.error("Failed to load metrics:",d),t("Failed to load bookmarks")}m(!1)}async function D(d){if(y(d),!d.trim()){v([]),a("Enter a search term");return}a(`Searching for "${d}"...`);try{const f=await chrome.runtime.sendMessage({type:"SEARCH_BOOKMARKS",query:d});v(f||[]),a(`Found ${(f==null?void 0:f.length)||0} bookmarks matching "${d}"`)}catch(f){console.error("Search failed:",f),a("Search failed")}}function x(){chrome.runtime.openOptionsPage()}function E(){switch(r){case"dashboard":return p;case"actions":return b;case"search":return C;default:return"Ready"}}return e("div",{class:"app",children:[e("header",{class:"header",children:[e("h1",{children:"Sift"}),e("div",{class:"header-actions",children:[e("button",{class:"icon-btn",onClick:c,title:"Refresh",children:"↻"}),e("button",{class:"icon-btn",onClick:x,title:"Settings",children:"⚙"})]})]}),e("nav",{class:"tabs",children:[e("button",{class:`tab ${r==="dashboard"?"active":""}`,onClick:()=>l("dashboard"),children:"Health"}),e("button",{class:`tab ${r==="actions"?"active":""}`,onClick:()=>l("actions"),children:"Actions"}),e("button",{class:`tab ${r==="search"?"active":""}`,onClick:()=>l("search"),children:"Search"})]}),e("main",{class:"content",children:w?e("div",{class:"loading",children:[e("div",{class:"spinner"}),e("span",{children:"Analyzing bookmarks..."})]}):e(Z,{children:[r==="dashboard"&&i&&e(X,{metrics:i,onRefresh:c}),r==="search"&&e(ee,{query:g,results:k,onSearch:D}),r==="actions"&&i&&e(ie,{metrics:i,onActionComplete:c,onStatusChange:s})]})}),e("footer",{class:"status-bar",children:e("span",{class:"status-message",children:E()})})]})}Q(e(se,{}),document.getElementById("app"));
